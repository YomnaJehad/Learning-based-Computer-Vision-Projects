
Railway_Surveillance   - v1 GrayScaledOnly
==============================

This dataset was exported via roboflow.ai on October 25, 2021 at 9:02 AM GMT

It includes 508 images.
PeopleFromSurveillanceCameraView are annotated in Tensorflow Object Detection format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)
* Grayscale (CRT phosphor)

No image augmentation techniques were applied.


